import os
import io
import re
import json
import uuid
import secrets
import string
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple

from dotenv import load_dotenv
from pydantic import BaseModel, Field

# Database & ORM
from sqlalchemy import Column, String, Boolean, DateTime, ForeignKey, Integer, Text, Index, select, delete
from sqlalchemy.orm import declarative_base, relationship
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker

# Cryptography
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

# OTP & QR
import pyotp
import qrcode

# aiogram Telegram framework
from aiogram import Bot, Dispatcher, Router, types, F
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.context import FSMContext
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, BufferedInputFile
from aiogram.filters import Command, CommandStart
from fastapi import FastAPI, Request

# Load environment configuration
load_dotenv()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite+aiosqlite:///shieldvault.db")
PORT = int(os.getenv("PORT", "8000"))
WEBHOOK_URL = os.getenv("WEBHOOK_URL", "")
ADMIN_IDS = [int(i.strip()) for i in os.getenv("ADMIN_IDS", "").split(",") if i.strip()]

# Setup logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s - %(name)s - %(levelname)s - %(message)s")
logger = logging.getLogger("ShieldVault")

# Resolve PostgreSQL driver for async capabilities if required
if DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://")

# Async DB configuration
engine = create_async_engine(DATABASE_URL, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)
Base = declarative_base()

# --- CRYPTOGRAPHIC UTILITIES ---
ph = PasswordHasher()

def hash_master_password(password: str) -> str:
    return ph.hash(password)

def verify_master_password(hashed: str, password: str) -> bool:
    try:
        return ph.verify(hashed, password)
    except VerifyMismatchError:
        return False

def derive_encryption_key(master_password: str, salt_hex: str) -> bytes:
    salt = bytes.fromhex(salt_hex)
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000
    )
    return kdf.derive(master_password.encode())

def encrypt_payload(key: bytes, plaintext: str) -> str:
    if not plaintext:
        return ""
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode('utf-8'), None)
    return (nonce + ciphertext).hex()

def decrypt_payload(key: bytes, encrypted_hex: str) -> str:
    if not encrypted_hex:
        return ""
    try:
        data = bytes.fromhex(encrypted_hex)
        nonce = data[:12]
        ciphertext = data[12:]
        aesgcm = AESGCM(key)
        return aesgcm.decrypt(nonce, ciphertext, None).decode('utf-8')
    except Exception:
        return "[Decryption Error]"

def assess_password_strength(password: str) -> int:
    score = 1
    if len(password) >= 8:
        score += 1
    if len(password) >= 14:
        score += 1
    if re.search(r"[a-z]", password) and re.search(r"[A-Z]", password):
        score += 1
    if re.search(r"[0-9]", password) and re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        score += 1
    return score

# --- DATABASE MODELS ---
class DBUser(Base):
    __tablename__ = 'users'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    telegram_id = Column(String, unique=True, index=True, nullable=False)
    master_password_hash = Column(String, nullable=True)
    salt = Column(String, nullable=False)
    language = Column(String, default="en")
    auto_lock_seconds = Column(Integer, default=300)
    is_blocked = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class DBVaultItem(Base):
    __tablename__ = 'vault_items'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey('users.id', ondelete='CASCADE'), index=True, nullable=False)
    title = Column(Text, nullable=False)
    username = Column(Text, nullable=True)
    password = Column(Text, nullable=True)
    description = Column(Text, nullable=True)
    category = Column(String, default="General")
    tags = Column(Text, nullable=True)
    is_favorite = Column(Boolean, default=False)
    totp_secret = Column(Text, nullable=True)
    password_history = Column(Text, default="[]")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)

class DBBackup(Base):
    __tablename__ = 'backups'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, ForeignKey('users.id', ondelete='CASCADE'), index=True, nullable=False)
    backup_data = Column(Text, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

class DBTempShare(Base):
    __tablename__ = 'temp_shares'
    id = Column(String, primary_key=True)
    encrypted_data = Column(Text, nullable=False)
    expires_at = Column(DateTime, nullable=False)
    views_remaining = Column(Integer, default=1)

class DBAuditLog(Base):
    __tablename__ = 'audit_logs'
    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = Column(String, nullable=True)
    action = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

# --- TRANSLATIONS (ENGLISH & PERSIAN) ---
LOCALIZATION = {
    "en": {
        "welcome": "🛡️ **Welcome to ShieldVault**\n\nA Zero-Knowledge Password Manager for Telegram. All data is encrypted with AES-256-GCM using transient memory keys derived from your Master Password.\n\nType /help to review commands.",
        "not_registered": "⚠️ You are not registered yet. Please run /register.",
        "already_registered": "✅ You are registered. Please run /login to unlock your session.",
        "register_prompt": "🔒 Please enter a strong Master Password. This password generates your exclusive salt. We never save it plain!",
        "reg_success": "🎉 Registration successful! Run /login to initialize your decryption session.",
        "login_prompt": "🔑 Please enter your Master Password:",
        "login_success": "🔓 Vault unlocked. Session valid for {mins} minutes of continuous idle time.",
        "wrong_password": "❌ Password verification failed. Access denied.",
        "logged_out": "🔒 Session closed. Transient decryption keys cleared from server RAM.",
        "vault_menu": "🗄️ **Your Encrypted Vault**\nSelect an action to securely view or record items:",
        "no_items": "📦 Your vault has no records. Let's add some!",
        "add_item": "➕ **Add Record**\nLet's get started:",
        "item_title": "Enter Title (e.g. Google, Bank):",
        "item_username": "Enter Username / ID:",
        "item_password": "Enter Secret Password:",
        "item_category": "Enter Category Name:",
        "item_tags": "Enter tags separated by commas:",
        "item_desc": "Enter extra descriptive text:",
        "item_totp": "Enter 2FA TOTP secret key (optional, or 'none'):",
        "item_saved": "✅ Secure entry created successfully!",
        "item_deleted": "🗑️ Record moved to trash successfully.",
        "item_restored": "🔄 Record restored to active vault.",
        "locked": "🔒 Vault is locked! Run /login to access your credentials.",
        "pass_gen": "🎲 **Secure Password Generator**\nAdjust options and generate:",
        "stats_title": "📊 **Vault Health Summary**",
        "security_score": "🛡️ Security Health Score: ",
        "backup_prompt": "💾 Generating secure, password-encrypted copy...",
        "invalid_backup": "❌ Bad backup structure. Restoration cancelled.",
        "import_success": "✅ Restored backup file structure to current database storage.",
        "admin_only": "❌ Access denied.",
        "weak_warning": "⚠️ Low Entropy Detected!",
        "duplicate_warning": "🔄 Reused credential pattern identified!"
    },
    "fa": {
        "welcome": "🛡️ **به شیلدولت خوش آمدید**\n\nربات مدیریت پسورد صفر-دانش تلگرام. اطلاعات شما با روش AES-256-GCM با استفاده از کلید موقت در رم سرور رمزگذاری می‌شود.\n\nبرای لیست دستورات /help را بفرستید.",
        "not_registered": "⚠️ شما هنوز ثبت نام نکرده‌اید. لطفاً از دستور /register استفاده کنید.",
        "already_registered": "✅ ثبت نام انجام شده است. برای ورود از /login استفاده کنید.",
        "register_prompt": "🔒 لطفا رمز عبور اصلی خود را تعیین کنید. هیچ راه بازیابی وجود ندارد!",
        "reg_success": "🎉 ثبت نام با موفقیت انجام شد! دستور /login را برای ورود وارد کنید.",
        "login_prompt": "🔑 رمز عبور اصلی خود را برای بازکردن صندوق وارد کنید:",
        "login_success": "🔓 قفل صندوق باز شد. جلسه کاری شما برای {mins} دقیقه عدم فعالیت معتبر است.",
        "wrong_password": "❌ رمز عبور اصلی اشتباه است.",
        "logged_out": "🔒 جلسه کاری بسته شد. کلیدهای رمزگذاری به طور کامل از رم سرور پاک شدند.",
        "vault_menu": "🗄️ **صندوق امن شما**\nیک گزینه را انتخاب کنید:",
        "no_items": "📦 صندوق شما خالی است.",
        "add_item": "➕ **افزودن آیتم جدید**\nلطفاً مشخصات زیر را وارد کنید:",
        "item_title": "عنوان آیتم را وارد کنید (مانند گوگل، ایمیل شخصی):",
        "item_username": "نام کاربری را وارد کنید:",
        "item_password": "پسورد را وارد کنید:",
        "item_category": "دسته‌بندی را وارد کنید:",
        "item_tags": "تگ‌ها را با کاما جدا کنید:",
        "item_desc": "توضیحات اختیاری را وارد کنید:",
        "item_totp": "کلید TOTP / دو مرحله‌ای را وارد کنید (یا 'none'):",
        "item_saved": "✅ اطلاعات جدید رمزگذاری و ذخیره شد!",
        "item_deleted": "🗑️ آیتم با موفقیت به سطل زباله منتقل شد.",
        "item_restored": "🔄 آیتم بازیابی شد.",
        "locked": "🔒 صندوق قفل است! لطفا ابتدا با دستور /login قفل را باز کنید.",
        "pass_gen": "🎲 **تولیدکننده رمز امن**\nتنظیمات را انتخاب کرده و تولید کنید:",
        "stats_title": "📊 **وضعیت سلامت صندوق شما**",
        "security_score": "🛡️ امتیاز امنیت کلی: ",
        "backup_prompt": "💾 در حال دریافت فایل پشتیبان رمزگذاری شده...",
        "invalid_backup": "❌ فرمت فایل پشتیبان نامعتبر است.",
        "import_success": "✅ فایل پشتیبان با موفقیت بازیابی شد.",
        "admin_only": "❌ دسترسی غیرمجاز.",
        "weak_warning": "⚠️ رمز عبور ضعیف شناسایی شد!",
        "duplicate_warning": "🔄 پسورد تکراری شناسایی شد!"
    }
}

def get_text(lang: str, key: str) -> str:
    return LOCALIZATION.get(lang, LOCALIZATION["en"]).get(key, LOCALIZATION["en"].get(key, ""))

# --- FSM STATES ---
class VaultStates(StatesGroup):
    registering = State()
    logging_in = State()
    main_menu = State()
    
    # Add Item Flow
    add_title = State()
    add_username = State()
    add_password = State()
    add_category = State()
    add_tags = State()
    add_totp = State()
    add_description = State()
    
    # Edit Flow
    edit_password = State()
    
    # Operations
    searching = State()
    importing = State()
    sharing = State()

# --- BOT ROUTER & MIDDLEWARE INTERNALS ---
router = Router()

async def get_decryption_key(state: FSMContext, user: DBUser) -> Optional[bytes]:
    data = await state.get_data()
    last_active_str = data.get("last_active")
    key_hex = data.get("session_key")
    
    if not key_hex or not last_active_str:
        return None
        
    last_active = datetime.fromisoformat(last_active_str)
    if datetime.utcnow() - last_active > timedelta(seconds=user.auto_lock_seconds):
        await state.update_data(session_key=None, last_active=None)
        return None
        
    await state.update_data(last_active=datetime.utcnow().isoformat())
    return bytes.fromhex(key_hex)

async def log_audit(user_id: Optional[str], action: str):
    async with AsyncSessionLocal() as session:
        log = DBAuditLog(user_id=user_id, action=action)
        session.add(log)
        await session.commit()

# --- HANDLERS: START, HELP & AUTHENTICATION ---

@router.message(CommandStart())
async def cmd_start(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    
    # Handle Deep-linking Zero-Knowledge password sharing
    args = message.text.split()
    if len(args) > 1 and args[1].startswith("share_"):
        try:
            parts = args[1].split("_")
            share_id = parts[1]
            key_hex = parts[2]
            
            async with AsyncSessionLocal() as session:
                share_res = await session.execute(select(DBTempShare).where(DBTempShare.id == share_id))
                share = share_res.scalar_one_or_none()
                
                if not share or datetime.utcnow() > share.expires_at or share.views_remaining <= 0:
                    await message.answer("❌ This shared payload has expired or been viewed already.")
                    return
                
                dec_key = bytes.fromhex(key_hex)
                decrypted_val = decrypt_payload(dec_key, share.encrypted_data)
                
                share.views_remaining -= 1
                if share.views_remaining <= 0:
                    await session.delete(share)
                await session.commit()
                
                sent = await message.answer(
                    f"👀 **Decrypted Shared Content (Self-Destructs in 30s):**\n\n"
                    f"`{decrypted_val}`"
                )
                asyncio.create_task(delete_message_after_delay(message.bot, message.chat.id, sent.message_id, 30))
                return
        except Exception as e:
            logger.error(f"Error handling shared link: {e}")
            await message.answer("❌ Decryption error. The link metadata might be corrupted.")
            return

    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if not user:
            user = DBUser(telegram_id=telegram_id, salt=os.urandom(16).hex(), language="en")
            session.add(user)
            await session.commit()
            
        lang = user.language
        await message.answer(get_text(lang, "welcome"))

@router.message(Command("help"))
async def cmd_help(message: types.Message):
    await message.answer(
        "🛡️ **ShieldVault Operations Guide**\n\n"
        "🔑 **Security Commands:**\n"
        "/register - Setup Master Password\n"
        "/login - Authenticate current session\n"
        "/lock - Lock active vault state\n"
        "/logout - Destroy active symmetric sessions\n\n"
        "🗄️ **Vault Commands:**\n"
        "/vault - Open password vault manager\n"
        "/add - Directly append encrypted record\n"
        "/search - Query local database records\n"
        "/generate - Access complex custom random password tool\n"
        "/settings - Select preferred language and lock delay\n"
        "/backup - Generate custom encrypted payload file\n"
        "/import - Restore dynamic backup vault file\n"
        "/share - Instantly configure deep-link encrypted sharing"
    )

@router.message(Command("register"))
async def cmd_register(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if not user:
            user = DBUser(telegram_id=telegram_id, salt=os.urandom(16).hex())
            session.add(user)
            await session.commit()
            
        if user.master_password_hash:
            await message.answer(get_text(user.language, "already_registered"))
            return
            
        await message.answer(get_text(user.language, "register_prompt"))
        await state.set_state(VaultStates.registering)

@router.message(VaultStates.registering)
async def process_register(message: types.Message, state: FSMContext):
    master_pass = message.text.strip()
    telegram_id = str(message.from_user.id)
    
    try:
        await message.delete()
    except Exception:
        pass
        
    if len(master_pass) < 8 or not re.search(r"[0-9]", master_pass) or not re.search(r"[A-Z]", master_pass):
        await message.answer("❌ Password must be at least 8 characters long, contain numbers, and at least one uppercase letter.")
        return
        
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        user.master_password_hash = hash_master_password(master_pass)
        await session.commit()
        
        await message.answer(get_text(user.language, "reg_success"))
        await log_audit(user.id, "Registered Master Password")
        await state.clear()

@router.message(Command("login"))
async def cmd_login(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if not user or not user.master_password_hash:
            await message.answer("⚠️ Run /register before attempting authentication.")
            return
            
        await message.answer(get_text(user.language, "login_prompt"))
        await state.set_state(VaultStates.logging_in)

@router.message(VaultStates.logging_in)
async def process_login(message: types.Message, state: FSMContext):
    master_pass = message.text.strip()
    telegram_id = str(message.from_user.id)
    
    try:
        await message.delete()
    except Exception:
        pass
        
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        if verify_master_password(user.master_password_hash, master_pass):
            key = derive_encryption_key(master_pass, user.salt)
            await state.update_data(
                session_key=key.hex(),
                last_active=datetime.utcnow().isoformat()
            )
            await message.answer(get_text(user.language, "login_success").format(mins=int(user.auto_lock_seconds/60)))
            await log_audit(user.id, "Logged in successfully.")
            await state.set_state(VaultStates.main_menu)
        else:
            await message.answer(get_text(user.language, "wrong_password"))
            await log_audit(user.id, "Failed verification check.")

@router.message(Command("logout"))
@router.message(Command("lock"))
async def cmd_logout(message: types.Message, state: FSMContext):
    await state.clear()
    await message.answer("🔒 Credentials locked. All transient decryption keys evicted from volatile RAM.")

# --- VAULT INTERFACES (CRUD) ---

@router.message(Command("vault"))
async def cmd_vault(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if not user:
            return
            
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
            
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔑 View Passwords", callback_data="vault_list_0"),
             InlineKeyboardButton(text="➕ Add New", callback_data="vault_add")],
            [InlineKeyboardButton(text="📊 Security Score", callback_data="vault_score"),
             InlineKeyboardButton(text="⭐ Favorites", callback_data="vault_favorites")],
            [InlineKeyboardButton(text="⚙️ Settings", callback_data="vault_settings")]
        ])
        await message.answer(get_text(user.language, "vault_menu"), reply_markup=kb)

@router.message(Command("add"))
async def cmd_add_shortcut(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
            
        await message.answer(get_text(user.language, "item_title"))
        await state.set_state(VaultStates.add_title)

@router.callback_query(F.data == "vault_add")
async def cb_vault_add(callback: types.CallbackQuery, state: FSMContext):
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.answer(get_text(user.language, "locked"))
            return
            
        await callback.message.edit_text(get_text(user.language, "item_title"))
        await state.set_state(VaultStates.add_title)

@router.message(VaultStates.add_title)
async def process_add_title(message: types.Message, state: FSMContext):
    await state.update_data(temp_title=message.text)
    await message.answer("👤 Enter Username / Email ID:")
    await state.set_state(VaultStates.add_username)

@router.message(VaultStates.add_username)
async def process_add_username(message: types.Message, state: FSMContext):
    await state.update_data(temp_username=message.text)
    await message.answer("🔑 Enter Record Password (or use /generate inside a dynamic generator menu first):")
    await state.set_state(VaultStates.add_password)

@router.message(VaultStates.add_password)
async def process_add_password(message: types.Message, state: FSMContext):
    await state.update_data(temp_password=message.text)
    try:
        await message.delete()
    except Exception:
        pass
    await message.answer("📂 Enter Category Name (or general):")
    await state.set_state(VaultStates.add_category)

@router.message(VaultStates.add_category)
async def process_add_category(message: types.Message, state: FSMContext):
    await state.update_data(temp_category=message.text)
    await message.answer("⏱️ Enter TOTP Secret (or type 'none'):")
    await state.set_state(VaultStates.add_totp)

@router.message(VaultStates.add_totp)
async def process_add_totp(message: types.Message, state: FSMContext):
    totp_val = message.text.strip()
    await state.update_data(temp_totp="" if totp_val.lower() == "none" else totp_val)
    await message.answer("📝 Enter Description notes (or 'none'):")
    await state.set_state(VaultStates.add_description)

@router.message(VaultStates.add_description)
async def process_add_desc(message: types.Message, state: FSMContext):
    desc_val = message.text.strip()
    desc_to_save = "" if desc_val.lower() == "none" else desc_val
    
    data = await state.get_data()
    telegram_id = str(message.from_user.id)
    
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key_hex = data.get("session_key")
        if not key_hex:
            await message.answer(get_text(user.language, "locked"))
            return
            
        key = bytes.fromhex(key_hex)
        
        enc_title = encrypt_payload(key, data["temp_title"])
        enc_username = encrypt_payload(key, data["temp_username"])
        enc_password = encrypt_payload(key, data["temp_password"])
        enc_category = encrypt_payload(key, data["temp_category"])
        enc_desc = encrypt_payload(key, desc_to_save)
        enc_totp = encrypt_payload(key, data["temp_totp"]) if data["temp_totp"] else None
        
        item = DBVaultItem(
            user_id=user.id,
            title=enc_title,
            username=enc_username,
            password=enc_password,
            category=enc_category,
            description=enc_desc,
            totp_secret=enc_totp,
            password_history="[]"
        )
        session.add(item)
        await session.commit()
        
        await message.answer(get_text(user.language, "item_saved"))
        await log_audit(user.id, "Saved encrypted vault item.")
        await state.set_state(VaultStates.main_menu)

# List credentials callback
@router.callback_query(F.data.startswith("vault_list_"))
async def cb_vault_list(callback: types.CallbackQuery, state: FSMContext):
    page = int(callback.data.split("_")[2])
    telegram_id = str(callback.from_user.id)
    
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        result_items = await session.execute(
            select(DBVaultItem).where(DBVaultItem.user_id == user.id, DBVaultItem.deleted_at.is_(None))
        )
        items = result_items.scalars().all()
        
        decrypted_items = []
        for it in items:
            decrypted_items.append((it.id, decrypt_payload(key, it.title)))
            
        total_items = len(decrypted_items)
        items_per_page = 5
        start_idx = page * items_per_page
        end_idx = start_idx + items_per_page
        page_items = decrypted_items[start_idx:end_idx]
        
        kb_list = []
        for item_id, dec_title in page_items:
            kb_list.append([InlineKeyboardButton(text=f"🔑 {dec_title}", callback_data=f"item_view_{item_id}")])
            
        nav_buttons = []
        if page > 0:
            nav_buttons.append(InlineKeyboardButton(text="⬅️ Back", callback_data=f"vault_list_{page-1}"))
        if end_idx < total_items:
            nav_buttons.append(InlineKeyboardButton(text="Next ➡️", callback_data=f"vault_list_{page+1}"))
            
        if nav_buttons:
            kb_list.append(nav_buttons)
            
        kb_list.append([InlineKeyboardButton(text="🔙 Main Menu", callback_data="vault_main")])
        
        await callback.message.edit_text(
            f"📦 **Your Locked Vault Items (Page {page+1})**",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_list)
        )

# View individual vault item
@router.callback_query(F.data.startswith("item_view_"))
async def cb_item_view(callback: types.CallbackQuery, state: FSMContext):
    item_id = callback.data.split("_")[2]
    telegram_id = str(callback.from_user.id)
    
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        result_item = await session.execute(select(DBVaultItem).where(DBVaultItem.id == item_id))
        item = result_item.scalar_one_or_none()
        
        if not item:
            await callback.answer("Item not found.")
            return
            
        dec_title = decrypt_payload(key, item.title)
        dec_user = decrypt_payload(key, item.username)
        dec_pass = decrypt_payload(key, item.password)
        dec_category = decrypt_payload(key, item.category)
        dec_desc = decrypt_payload(key, item.description) if item.description else ""
        
        totp_section = ""
        if item.totp_secret:
            dec_totp_seed = decrypt_payload(key, item.totp_secret)
            try:
                totp = pyotp.TOTP(dec_totp_seed)
                totp_section = f"\n🕒 **2FA (TOTP):** `{totp.now()}`"
            except Exception:
                totp_section = "\n🕒 **2FA Code:** [Invalid seed configuration]"
                
        warnings = ""
        score = assess_password_strength(dec_pass)
        if score <= 2:
            warnings += f"\n⚠️ **Warning:** {get_text(user.language, 'weak_warning')}"
            
        text_resp = (
            f"📋 **Credential Record**\n\n"
            f"🔹 **Title:** {dec_title}\n"
            f"👤 **Username:** `{dec_user}`\n"
            f"🔑 **Password:** `{dec_pass}`\n"
            f"📂 **Category:** {dec_category}\n"
            f"📝 **Notes:** {dec_desc}"
            f"{totp_section}"
            f"{warnings}\n"
        )
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="⭐ Toggle Favorite" if not item.is_favorite else "🌟 Unfavorite", callback_data=f"item_fav_{item.id}"),
             InlineKeyboardButton(text="🗑️ Delete Item", callback_data=f"item_del_{item.id}")],
            [InlineKeyboardButton(text="✏️ Edit Password", callback_data=f"item_editpass_{item.id}"),
             InlineKeyboardButton(text="⏱️ QR for 2FA", callback_data=f"item_qr_{item.id}")],
            [InlineKeyboardButton(text="🔙 Back", callback_data="vault_list_0")]
        ])
        
        sent_msg = await callback.message.edit_text(text_resp, reply_markup=kb)
        asyncio.create_task(delete_message_after_delay(callback.bot, callback.message.chat.id, sent_msg.message_id, 45))

async def delete_message_after_delay(bot: Bot, chat_id: int, message_id: int, delay: int):
    await asyncio.sleep(delay)
    try:
        await bot.delete_message(chat_id=chat_id, message_id=message_id)
    except Exception:
        pass

# Dynamic main menu navigation callback
@router.callback_query(F.data == "vault_main")
async def cb_vault_main(callback: types.CallbackQuery, state: FSMContext):
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔑 View Passwords", callback_data="vault_list_0"),
             InlineKeyboardButton(text="➕ Add New", callback_data="vault_add")],
            [InlineKeyboardButton(text="📊 Security Score", callback_data="vault_score"),
             InlineKeyboardButton(text="⭐ Favorites", callback_data="vault_favorites")],
            [InlineKeyboardButton(text="⚙️ Settings", callback_data="vault_settings")]
        ])
        await callback.message.edit_text(get_text(user.language, "vault_menu"), reply_markup=kb)

# Favorites filtering
@router.callback_query(F.data == "vault_favorites")
async def cb_vault_favorites(callback: types.CallbackQuery, state: FSMContext):
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        result_items = await session.execute(
            select(DBVaultItem).where(DBVaultItem.user_id == user.id, DBVaultItem.is_favorite.is_(True), DBVaultItem.deleted_at.is_(None))
        )
        items = result_items.scalars().all()
        
        kb_list = []
        for it in items:
            dec_title = decrypt_payload(key, it.title)
            kb_list.append([InlineKeyboardButton(text=f"⭐️ {dec_title}", callback_data=f"item_view_{it.id}")])
            
        kb_list.append([InlineKeyboardButton(text="🔙 Main Menu", callback_data="vault_main")])
        await callback.message.edit_text("⭐ **Favorite Records:**", reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_list))

@router.callback_query(F.data.startswith("item_fav_"))
async def cb_item_favorite(callback: types.CallbackQuery, state: FSMContext):
    item_id = callback.data.split("_")[2]
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBVaultItem).where(DBVaultItem.id == item_id))
        item = result.scalar_one_or_none()
        if item:
            item.is_favorite = not item.is_favorite
            await session.commit()
            await callback.answer("⭐ Favorites updated!")
            await cb_item_view(callback, state)

@router.callback_query(F.data.startswith("item_del_"))
async def cb_item_delete(callback: types.CallbackQuery, state: FSMContext):
    item_id = callback.data.split("_")[2]
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        result_item = await session.execute(select(DBVaultItem).where(DBVaultItem.id == item_id))
        item = result_item.scalar_one_or_none()
        if item:
            item.deleted_at = datetime.utcnow()
            await session.commit()
            await callback.answer(get_text(user.language, "item_deleted"))
            await log_audit(user.id, "Deleted Vault Item")
            await cb_vault_list(callback, state)

# QR Code Generation for TOTP Compatibility
@router.callback_query(F.data.startswith("item_qr_"))
async def cb_item_qr(callback: types.CallbackQuery, state: FSMContext):
    item_id = callback.data.split("_")[2]
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        result_item = await session.execute(select(DBVaultItem).where(DBVaultItem.id == item_id))
        item = result_item.scalar_one_or_none()
        
        if item and item.totp_secret:
            dec_totp = decrypt_payload(key, item.totp_secret)
            dec_title = decrypt_payload(key, item.title)
            provisioning_uri = pyotp.totp.TOTP(dec_totp).provisioning_uri(name=user.telegram_id, issuer_name=dec_title)
            
            qr = qrcode.QRCode(version=1, box_size=10, border=5)
            qr.add_data(provisioning_uri)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            
            buffer = io.BytesIO()
            img.save(buffer, format="PNG")
            buffer.seek(0)
            
            await callback.message.answer_photo(
                photo=BufferedInputFile(buffer.read(), filename="totp_qr.png"),
                caption=f"📲 Use Google or Microsoft Authenticator to configure 2FA for: {dec_title}"
            )
            await callback.answer()
        else:
            await callback.answer("No 2FA/TOTP configuration configured for this vault record.")

# Edit Password flow
@router.callback_query(F.data.startswith("item_editpass_"))
async def cb_item_editpass(callback: types.CallbackQuery, state: FSMContext):
    item_id = callback.data.split("_")[2]
    await state.update_data(editing_item_id=item_id)
    await callback.message.edit_text("✏️ Enter the new password for this record:")
    await state.set_state(VaultStates.edit_password)

@router.message(VaultStates.edit_password)
async def process_edit_password(message: types.Message, state: FSMContext):
    new_pass = message.text.strip()
    data = await state.get_data()
    item_id = data.get("editing_item_id")
    telegram_id = str(message.from_user.id)
    
    try:
        await message.delete()
    except Exception:
        pass
        
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        key_hex = data.get("session_key")
        if not key_hex:
            await message.answer(get_text(user.language, "locked"))
            return
            
        key = bytes.fromhex(key_hex)
        result_item = await session.execute(select(DBVaultItem).where(DBVaultItem.id == item_id))
        item = result_item.scalar_one_or_none()
        
        if item:
            history = json.loads(item.password_history or "[]")
            history.append({
                "password": item.password,
                "changed_at": datetime.utcnow().isoformat()
            })
            item.password_history = json.dumps(history)
            item.password = encrypt_payload(key, new_pass)
            await session.commit()
            await message.answer("✅ Password updated in secure vault history storage!")
            await log_audit(user.id, "Edited item password.")
            
        await state.set_state(VaultStates.main_menu)

# --- SEARCH FEATURE ---
@router.message(Command("search"))
async def cmd_search(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
        await message.answer("🔍 Enter Title search criteria:")
        await state.set_state(VaultStates.searching)

@router.message(VaultStates.searching)
async def process_search(message: types.Message, state: FSMContext):
    query = message.text.strip().lower()
    telegram_id = str(message.from_user.id)
    
    async with AsyncSessionLocal() as session:
        result_user = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result_user.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            await state.clear()
            return
            
        result_items = await session.execute(
            select(DBVaultItem).where(DBVaultItem.user_id == user.id, DBVaultItem.deleted_at.is_(None))
        )
        items = result_items.scalars().all()
        
        matches = []
        for it in items:
            dec_title = decrypt_payload(key, it.title).lower()
            dec_username = decrypt_payload(key, it.username).lower() if it.username else ""
            if query in dec_title or query in dec_username:
                matches.append(it)
                
        if not matches:
            await message.answer("❌ No matching encrypted credentials found.")
        else:
            kb_list = []
            for item in matches:
                dec_title = decrypt_payload(key, item.title)
                kb_list.append([InlineKeyboardButton(text=f"🔑 {dec_title}", callback_data=f"item_view_{item.id}")])
            await message.answer("🔎 Search Results:", reply_markup=InlineKeyboardMarkup(inline_keyboard=kb_list))
            
        await state.set_state(VaultStates.main_menu)

# --- ADVANCED ONE-TIME SECURE SHARING ---
@router.message(Command("share"))
async def cmd_share(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
        await message.answer("📲 Enter the plain-text message or password you wish to share as a single-use deep link:")
        await state.set_state(VaultStates.sharing)

@router.message(VaultStates.sharing)
async def process_sharing(message: types.Message, state: FSMContext):
    payload = message.text.strip()
    try:
        await message.delete()
    except Exception:
        pass
        
    share_id = secrets.token_hex(8)
    temp_key = os.urandom(16)
    
    enc_data = encrypt_payload(temp_key, payload)
    
    async with AsyncSessionLocal() as session:
        temp_share = DBTempShare(
            id=share_id,
            encrypted_data=enc_data,
            expires_at=datetime.utcnow() + timedelta(hours=24),
            views_remaining=1
        )
        session.add(temp_share)
        await session.commit()
        
    bot_info = await message.bot.get_me()
    deep_link = f"https://t.me/{bot_info.username}?start=share_{share_id}_{temp_key.hex()}"
    
    await message.answer(
        f"🔗 **Secure One-Time Share Link:**\n\n"
        f"`{deep_link}`\n\n"
        f"Anyone with this link can view this secret exactly once. The server cannot decrypt this record without the deep link key parameter."
    )
    await state.set_state(VaultStates.main_menu)

# --- PASSWORD GENERATOR ---
@router.message(Command("generate"))
async def cmd_generate_menu(message: types.Message):
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()_+"
    pwd = "".join(secrets.choice(alphabet) for _ in range(16))
    await message.answer(
        f"🎲 **Your Secure Password**\n\n"
        f"🔑 Code: `{pwd}`\n\n"
        f"Ensure you record it securely inside your vault repository!"
    )

# --- BACKUPS ENGINE ---
@router.message(Command("backup"))
async def cmd_backup_file(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
            
        result_items = await session.execute(
            select(DBVaultItem).where(DBVaultItem.user_id == user.id, DBVaultItem.deleted_at.is_(None))
        )
        items = result_items.scalars().all()
        
        backup_records = []
        for it in items:
            backup_records.append({
                "title_enc": it.title,
                "user_enc": it.username,
                "pass_enc": it.password,
                "cat_enc": it.category,
                "desc_enc": it.description,
                "totp_enc": it.totp_secret
            })
            
        raw_json = json.dumps(backup_records)
        aes_backup = AESGCM(key)
        nonce = os.urandom(12)
        encrypted_backup = aes_backup.encrypt(nonce, raw_json.encode('utf-8'), None)
        final_payload = (nonce + encrypted_backup).hex()
        
        backup_log = DBBackup(user_id=user.id, backup_data=final_payload)
        session.add(backup_log)
        await session.commit()
        
        buffer = io.BytesIO(final_payload.encode('utf-8'))
        buffer.seek(0)
        
        await message.answer_document(
            document=BufferedInputFile(buffer.read(), filename="shieldvault_export.backup"),
            caption="🔒 **ShieldVault Highly Secure Backup File**\n\nThis file is encrypted. It can only be decrypted when you upload it with this bot during an active authenticated session."
        )

@router.message(Command("import"))
async def cmd_import_file(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            return
            
        await message.answer("💾 Please send or upload the `.backup` document containing your previously exported vault credentials.")
        await state.set_state(VaultStates.importing)

@router.message(VaultStates.importing, F.document)
async def process_import_doc(message: types.Message, state: FSMContext):
    telegram_id = str(message.from_user.id)
    bot = message.bot
    
    file_info = await bot.get_file(message.document.file_id)
    file_bytes = await bot.download_file(file_info.file_path)
    encrypted_payload_hex = file_bytes.read().decode('utf-8')
    
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await message.answer(get_text(user.language, "locked"))
            await state.clear()
            return
            
        try:
            data = bytes.fromhex(encrypted_payload_hex)
            nonce = data[:12]
            ciphertext = data[12:]
            aes_backup = AESGCM(key)
            decrypted_json_bytes = aes_backup.decrypt(nonce, ciphertext, None)
            records = json.loads(decrypted_json_bytes.decode('utf-8'))
            
            for rec in records:
                item = DBVaultItem(
                    user_id=user.id,
                    title=rec["title_enc"],
                    username=rec["user_enc"],
                    password=rec["pass_enc"],
                    category=rec["cat_enc"],
                    description=rec["desc_enc"],
                    totp_secret=rec["totp_enc"]
                )
                session.add(item)
                
            await session.commit()
            await message.answer(get_text(user.language, "import_success"))
            await log_audit(user.id, "Successfully Restored Credentials Archive")
            
        except Exception as e:
            logger.error(f"Failed parsing backup stream: {e}")
            await message.answer(get_text(user.language, "invalid_backup"))
            
        await state.set_state(VaultStates.main_menu)

# --- SECURITY SCORE AUDITING ROUTINE ---
@router.callback_query(F.data == "vault_score")
async def cb_vault_score(callback: types.CallbackQuery, state: FSMContext):
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        key = await get_decryption_key(state, user)
        if not key:
            await callback.message.edit_text(get_text(user.language, "locked"))
            return
            
        result_items = await session.execute(
            select(DBVaultItem).where(DBVaultItem.user_id == user.id, DBVaultItem.deleted_at.is_(None))
        )
        items = result_items.scalars().all()
        
        if not items:
            await callback.message.edit_text("ℹ️ No items available in vault to audit.")
            return
            
        total_items = len(items)
        weak_count = 0
        password_occurrences = {}
        
        for it in items:
            raw_pwd = decrypt_payload(key, it.password)
            score = assess_password_strength(raw_pwd)
            if score <= 2:
                weak_count += 1
            password_occurrences[raw_pwd] = password_occurrences.get(raw_pwd, 0) + 1
            
        duplicate_count = sum(count for count in password_occurrences.values() if count > 1)
        
        safe_ratio = 1.0
        if total_items > 0:
            safe_ratio = (total_items - (weak_count + (duplicate_count / 2))) / total_items
        score_percentage = max(0, min(100, int(safe_ratio * 100)))
        
        audit_msg = (
            f"📊 **ShieldVault Audit Results**\n\n"
            f"🔍 Audited Records: **{total_items}**\n"
            f"🔴 Weak Passwords: **{weak_count}**\n"
            f"🔄 Reused/Duplicate Passwords: **{duplicate_count}**\n\n"
            f"🛡️ **Overall Security Score: {score_percentage}%**\n"
        )
        
        kb = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="🔙 Back", callback_data="vault_main")]
        ])
        await callback.message.edit_text(audit_msg, reply_markup=kb)

# --- SETTINGS PROFILES ---
@router.callback_query(F.data.startswith("set_lang_"))
async def cb_set_lang(callback: types.CallbackQuery):
    lang_code = callback.data.split("_")[2]
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            user.language = lang_code
            await session.commit()
            await callback.answer(f"Language set to: {lang_code.upper()}")
            # Re-render menu
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🇮🇷 Persian (Farsi)", callback_data="set_lang_fa"),
                 InlineKeyboardButton(text="🇺🇸 English", callback_data="set_lang_en")],
                [InlineKeyboardButton(text="⏱️ Lock: 1 Min", callback_data="set_lock_60"),
                 InlineKeyboardButton(text="⏱️ 5 Min", callback_data="set_lock_300")],
                [InlineKeyboardButton(text="🔙 Main Menu", callback_data="vault_main")]
            ])
            await callback.message.edit_text("⚙️ **ShieldVault Settings Profile**", reply_markup=kb)

@router.callback_query(F.data.startswith("set_lock_"))
async def cb_set_lock(callback: types.CallbackQuery):
    seconds = int(callback.data.split("_")[2])
    telegram_id = str(callback.from_user.id)
    async with AsyncSessionLocal() as session:
        result = await session.execute(select(DBUser).where(DBUser.telegram_id == telegram_id))
        user = result.scalar_one_or_none()
        if user:
            user.auto_lock_seconds = seconds
            await session.commit()
            await callback.answer(f"Session Lock Time adjusted to {seconds} seconds.")

# --- ADMIN PANEL EXECUTION ---
@router.message(Command("admin"))
async def cmd_admin_panel(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    async with AsyncSessionLocal() as session:
        users = (await session.execute(select(DBUser))).scalars().all()
        items_count = len((await session.execute(select(DBVaultItem))).scalars().all())
        
        await message.answer(
            f"👑 **ShieldVault System Admin Summary**\n\n"
            f"👥 Registered Users: **{len(users)}**\n"
            f"📦 Total Database Items: **{items_count}**\n"
            f"🛠️ Health: **Operational & Safe**"
        )

# --- WEBHOOK & FASTAPI CORE INTEGRATION ---
bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
dp.include_router(router)

app = FastAPI(title="ShieldVault Web Server Wrapper")

@app.on_event("startup")
async def on_startup():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    logger.info("Local SQLite database verified.")
    
    if WEBHOOK_URL:
        url_webhook = f"{WEBHOOK_URL.rstrip('/')}/webhook"
        await bot.set_webhook(url=url_webhook, drop_pending_updates=True)
        logger.info(f"Telegram Webhook configured to: {url_webhook}")
    else:
        logger.info("Initializing bot in fallback dynamic polling mode...")

@app.post("/webhook")
async def telegram_webhook_router(request: Request):
    try:
        update_json = await request.json()
        update = types.Update.model_validate(update_json, context={"bot": bot})
        await dp.feed_update(bot, update)
    except Exception as e:
        logger.error(f"Error handling webhook update: {e}")
    return {"status": "ok"}

@app.on_event("shutdown")
async def on_shutdown():
    await bot.session.close()
    await engine.dispose()
    logger.info("Volatile execution structures safely recycled.")

async def start_polling_fallback():
    await bot.delete_webhook()
    await dp.start_polling(bot)

if __name__ == "__main__":
    import uvicorn
    if not WEBHOOK_URL:
        asyncio.run(start_polling_fallback())
    else:
        uvicorn.run("main:app", host="0.0.0.0", port=PORT, reload=False)